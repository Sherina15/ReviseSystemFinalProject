package InventoryAndSchedulingSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class EditSchedule extends javax.swing.JFrame {


    public EditSchedule() 
    {
        initComponents();
        
        ownerName_TextField.setEditable(false);
        petName_TextField.setEditable(false);
        phoneNumber_TextField.setEditable(false);
        dateChooser_TextField.setEditable(false);
        time_TextField.setEditable(false);
        petSize_TextField.setEditable(false);
        serviceType_TextField.setEditable(false);
        price_TextField.setEditable(false);
        
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(EditSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";    
   
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);   
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        clientShop_Logo = new javax.swing.JLabel();
        editSchedule_Label = new javax.swing.JLabel();
        petName_Label = new javax.swing.JLabel();
        ownerName_Label = new javax.swing.JLabel();
        phoneNumber_Label = new javax.swing.JLabel();
        petSize_Label = new javax.swing.JLabel();
        serviceType_Label = new javax.swing.JLabel();
        date_Label = new javax.swing.JLabel();
        time_Label = new javax.swing.JLabel();
        price_Label = new javax.swing.JLabel();
        editSchedule_ScrollPane = new javax.swing.JScrollPane();
        editSchedule_Table = new javax.swing.JTable();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        finished_Button = new javax.swing.JButton();
        searchBar_TextField = new javax.swing.JTextField();
        ownerName_TextField = new javax.swing.JTextField();
        petName_TextField = new javax.swing.JTextField();
        phoneNumber_TextField = new javax.swing.JTextField();
        time_TextField = new javax.swing.JTextField();
        petSize_TextField = new javax.swing.JTextField();
        serviceType_TextField = new javax.swing.JTextField();
        price_TextField = new javax.swing.JTextField();
        back_Button = new javax.swing.JButton();
        dateChooser_TextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT SCHEDULE");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        editSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        editSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));
        editSchedule_Label.setText("Edit Schedule");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editSchedule_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 682, Short.MAX_VALUE)
                .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(clientShop_Logo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editSchedule_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 90));

        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        petName_Label.setText("Pet's Name");
        whole_Panel.add(petName_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ownerName_Label.setText("Owner's Name");
        whole_Panel.add(ownerName_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Contact Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, -1));

        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        petSize_Label.setText("Pet's Size ");
        whole_Panel.add(petSize_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, -1, -1));

        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        serviceType_Label.setText("Service Type");
        whole_Panel.add(serviceType_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        date_Label.setText("Date");
        whole_Panel.add(date_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, -1));

        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time_Label.setText("Time");
        whole_Panel.add(time_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, -1, -1));

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");
        whole_Panel.add(price_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 630, -1, -1));

        editSchedule_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Owner's Name", "Pet's Name", "Contact No.", "Service Type", "Pet's Size", "Price", "Time", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        editSchedule_Table.getTableHeader().setReorderingAllowed(false);
        editSchedule_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editSchedule_TableMouseClicked(evt);
            }
        });
        editSchedule_ScrollPane.setViewportView(editSchedule_Table);
        if (editSchedule_Table.getColumnModel().getColumnCount() > 0) {
            editSchedule_Table.getColumnModel().getColumn(0).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(1).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(2).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(3).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(4).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(5).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(6).setResizable(false);
            editSchedule_Table.getColumnModel().getColumn(7).setResizable(false);
        }

        whole_Panel.add(editSchedule_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, 840, 560));

        edit_Button.setBackground(new java.awt.Color(204, 204, 204));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        edit_Button.setText("Edit");
        edit_Button.setToolTipText("Edit Schedule");
        edit_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(edit_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 710, 90, 30));

        delete_Button.setBackground(new java.awt.Color(204, 204, 204));
        delete_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        delete_Button.setText("Delete");
        delete_Button.setToolTipText("Delete Schedule");
        delete_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(delete_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 710, 110, 30));

        finished_Button.setBackground(new java.awt.Color(204, 204, 204));
        finished_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        finished_Button.setText("Finish Schedule");
        finished_Button.setToolTipText("Add to Completed Schedule");
        finished_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        finished_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finished_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(finished_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 710, 110, 30));

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBar_TextFieldActionPerformed(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(searchBar_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 200, 30));

        ownerName_TextField.setText("                                                         ");
        ownerName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(ownerName_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 200, 30));

        petName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(petName_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 200, 30));

        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 200, 30));

        time_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(time_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 200, 30));

        petSize_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(petSize_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 520, 200, 30));

        serviceType_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(serviceType_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 590, 200, 30));

        price_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(price_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 660, 200, 30));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Close");
        back_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(back_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 710, 132, 35));

        dateChooser_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        dateChooser_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(dateChooser_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 200, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Client Information");
        whole_Panel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 1080, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 784, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    static int selectedRowIndex;
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM schedule_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)editSchedule_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Owner_Name"));
                    vec.add(rs.getString("Pet_Name"));
                    vec.add(rs.getString("ContactNumber"));
                    vec.add(rs.getString("ServiceType"));
                    vec.add(rs.getString("PetSize"));
                    vec.add(rs.getString("Price"));
                    vec.add(rs.getString("Time"));
                    vec.add(rs.getString("Date"));
                    
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed

            String Schedule_Owner = ownerName_TextField.getText();
            String Schedule_Pet = petName_TextField.getText();
            String Schedule_ContactNumber = phoneNumber_TextField.getText();
            String Schedule_date = dateChooser_TextField.getText();
            String Schedule_Time = time_TextField.getText();
            String Schedule_ServiceType = serviceType_TextField.getText();
            String Schedule_PetSize = petSize_TextField.getText();
            String Schedule_Price = price_TextField.getText();
            
       if(ownerName_TextField.getText().equals("")|| petName_TextField.getText().equals("")||phoneNumber_TextField.getText().equals("")||dateChooser_TextField.getText().equals("")||time_TextField.getText().equals("")||serviceType_TextField.getText().equals("")||petSize_TextField.getText().equals("")||price_TextField.getText().equals(""))
       {
          JOptionPane.showMessageDialog(null, "Empty fields.", "Error: Missing Field",JOptionPane.ERROR_MESSAGE);
                        
       }
       else{
           
       



        
       int choice = JOptionPane.showConfirmDialog(null, "are you sure you want to edit", "edit",JOptionPane.YES_NO_OPTION);
       
       if (choice == JOptionPane.YES_OPTION )
       {
           
            

             
            UpdateSchedule updateScheduleModule = new UpdateSchedule();

            JOptionPane.showMessageDialog(null, Schedule_Time);
            
            updateScheduleModule.petName_TextField.setText(Schedule_Pet);
            updateScheduleModule.ownerName_TextField.setText(Schedule_Owner);
            updateScheduleModule.phoneNumber_TextField.setText(Schedule_ContactNumber);
            updateScheduleModule.dateChooser_TextField.setText(Schedule_date);
            updateScheduleModule.time_TextField.setText(Schedule_Time);
            updateScheduleModule.serviceType_ComboBox.setSelectedItem(Schedule_ServiceType);
            updateScheduleModule.petSize_ComboBox.setSelectedItem(Schedule_PetSize);
            updateScheduleModule.price_TextField.setText(Schedule_Price);

            updateScheduleModule.setVisible(true);
            dispose(); 
       }
       else if (choice == JOptionPane.NO_OPTION)
       {
           JOptionPane.showMessageDialog(null, "cancel");
       }
       }
       
        
        
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
                JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    private void editSchedule_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editSchedule_TableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel)editSchedule_Table.getModel();
        int selectedIndex = editSchedule_Table.getSelectedRow();

        selectedRowIndex = editSchedule_Table.getSelectedRow();
    
        ownerName_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        petName_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        phoneNumber_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
        serviceType_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
        petSize_TextField.setText(dtm.getValueAt(selectedIndex, 4).toString());
        price_TextField.setText(dtm.getValueAt(selectedIndex, 5).toString());
        time_TextField.setText(dtm.getValueAt(selectedIndex, 6).toString());
        dateChooser_TextField.setText(dtm.getValueAt(selectedIndex, 7).toString());

        
       
        
    }//GEN-LAST:event_editSchedule_TableMouseClicked

    private void delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_ButtonActionPerformed
        String Schedule_Owner = ownerName_TextField.getText();
        String Schedule_Pet = petName_TextField.getText();
        String Schedule_ContactNumber = phoneNumber_TextField.getText();
        String Schedule_Date = dateChooser_TextField.getText();
        String Schedule_Time = time_TextField.getText();
        String Schedule_ServiceType = serviceType_TextField.getText();
        String Schedule_PetSize = petSize_TextField.getText();
        String Schedule_Price = price_TextField.getText();
        
        DefaultTableModel dtm = (DefaultTableModel)editSchedule_Table.getModel();
        int selectedIndex = editSchedule_Table.getSelectedRow();
        
        if (selectedIndex != -1) 
        {
            int choice = JOptionPane.showConfirmDialog(this,"Do you sure want to delete"+ Schedule_Owner,"Delete",JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION )
                {
                    try
                    {
                        Class.forName(dbDriver);
                        con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword); 

                        insert = con.prepareStatement("DELETE FROM schedule_database WHERE Owner_Name =? AND Pet_Name=? AND Date=? AND Time=? ");
                        insert.setString(1, Schedule_Owner);
                        insert.setString(2, Schedule_Pet);
                        insert.setString(3, Schedule_Date);
                        insert.setString(4, Schedule_Time);
                        

                        insert.executeUpdate();

                        JOptionPane.showMessageDialog(this, "Record Deleted ","Delete",JOptionPane.INFORMATION_MESSAGE);
                        tableUpdate();
                    }
                    catch(Exception e)
                    {

                    }
                }
                else if (choice == JOptionPane.NO_OPTION)
                {
                    JOptionPane.showMessageDialog(null, "Failed to delete profile.","Error",JOptionPane.ERROR_MESSAGE);   
                }
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_delete_ButtonActionPerformed

    private void finished_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finished_ButtonActionPerformed
        String Schedule_Owner = ownerName_TextField.getText();
        String Schedule_Pet = petName_TextField.getText();
        String Schedule_ContactNumber = phoneNumber_TextField.getText();
        String Schedule_Date = dateChooser_TextField.getText();
        String Schedule_Time = time_TextField.getText();
        String Schedule_ServiceType = serviceType_TextField.getText();
        String Schedule_PetSize = petSize_TextField.getText();
        String Schedule_Price = price_TextField.getText();
        
        DefaultTableModel dtm = (DefaultTableModel)editSchedule_Table.getModel();
        int selectedIndex = editSchedule_Table.getSelectedRow();
        

            
        if (selectedIndex != -1) 
        {  
           int choice = JOptionPane.showConfirmDialog(this,"Do you sure want to delete"+ Schedule_Owner, "Delete",JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION )
            {
                try
                {
                    Class.forName(dbDriver);
                    con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword); 
                    String queryRegister = "INSERT INTO appointmentreport_database (Owner_Name,Pet_Name, ContactNumber, ServiceType, PetSize,Price, Time,Date) VALUES ('"+Schedule_Owner+"', '"+Schedule_Pet+"', '"+Schedule_ContactNumber+"', '"+Schedule_ServiceType+"', '"+Schedule_PetSize+"', '"+Schedule_Price+"', '"+Schedule_Time+"', '"+Schedule_Date+"')";
                    pst = con.prepareStatement(queryRegister); 

                    int rowsAffected = pst.executeUpdate();

                        if (rowsAffected > 0) 
                        {
                                    JOptionPane.showMessageDialog(null, "Profile added successfully","Added",JOptionPane.INFORMATION_MESSAGE); 
                        }               

                    insert = con.prepareStatement("DELETE FROM schedule_database WHERE Owner_Name =? AND Pet_Name=? AND Date=? AND Time=? ");
                    insert.setString(1, Schedule_Owner);
                    insert.setString(2, Schedule_Pet);
                    insert.setString(3, Schedule_Date);
                    insert.setString(4, Schedule_Time);

                    insert.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Record Deleted ","Delete",JOptionPane.INFORMATION_MESSAGE);
                    tableUpdate();
                }
                catch(Exception e)
                            {
                            }
                
            
              
            
            
        }
        else if (choice == JOptionPane.NO_OPTION )
        {

        
        }

    }
    else
     {
         JOptionPane.showMessageDialog(null, "Select","Error",JOptionPane.ERROR_MESSAGE);   
     }
        
        
    }//GEN-LAST:event_finished_ButtonActionPerformed

    private void searchBar_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBar_TextFieldActionPerformed
      
    }//GEN-LAST:event_searchBar_TextFieldActionPerformed

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
        if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
        if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) editSchedule_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        editSchedule_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

 
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JTextField dateChooser_TextField;
    private javax.swing.JLabel date_Label;
    private javax.swing.JButton delete_Button;
    private javax.swing.JLabel editSchedule_Label;
    private javax.swing.JScrollPane editSchedule_ScrollPane;
    private javax.swing.JTable editSchedule_Table;
    private javax.swing.JButton edit_Button;
    private javax.swing.JButton finished_Button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel ownerName_Label;
    public static javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel petName_Label;
    private javax.swing.JTextField petName_TextField;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JTextField petSize_TextField;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JTextField serviceType_TextField;
    private javax.swing.JLabel time_Label;
    private javax.swing.JTextField time_TextField;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
