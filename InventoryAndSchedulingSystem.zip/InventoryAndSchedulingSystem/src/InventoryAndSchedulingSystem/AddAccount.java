package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewAdminAccount.viewAdminAccountList_Table;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AddAccount extends javax.swing.JFrame {

    public AddAccount() 
    {
        initComponents();
        
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AddAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";   
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        addAccount_Label = new javax.swing.JLabel();
        email_Icon = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        username_Icon = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        key_Icon = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        phoneNumber_Label = new javax.swing.JLabel();
        phone_Icon = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();
        add_Button = new javax.swing.JButton();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();
        name_TextField = new javax.swing.JTextField();
        email_TextField = new javax.swing.JTextField();
        name_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD ACCOUNT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.setToolTipText("");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        addAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        addAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        addAccount_Label.setText("ADD ACCOUNT");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addAccount_Label))
                .addContainerGap(246, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(addAccount_Label))
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 100));

        email_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_envelope.png"))); // NOI18N
        whole_Panel.add(email_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, 30));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, -1, -1));

        username_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_username.png"))); // NOI18N
        whole_Panel.add(username_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, -1, 30));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, 200, 32));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        key_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_key.png"))); // NOI18N
        whole_Panel.add(key_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, 30));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 430, 200, 30));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        phone_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        whole_Panel.add(phone_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, 30));

        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, 200, 32));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/2x2_client_logo.png"))); // NOI18N
        whole_Panel.add(clientShop_Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, -1, -1));

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");
        whole_Panel.add(clientShop_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 500, -1, -1));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add");
        add_Button.setToolTipText("Add Account");
        add_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, 90, 30));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.setToolTipText("Show Password");
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        whole_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 430, 30, 30));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.setToolTipText("Hide Password");
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        whole_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 430, 30, 30));
        whole_Panel.add(name_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 200, 32));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 200, 32));

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        name_Label.setText("Name");
        whole_Panel.add(name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel1.setText("Format: (Surname, Name)");
        whole_Panel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_user.png"))); // NOI18N
        whole_Panel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM registration_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)viewAdminAccountList_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Name"));
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                    vec.add(rs.getString("PhoneNumber"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearFields() 
    {
        name_TextField.setText("");
        email_TextField.setText("");
        username_TextField.setText("");
        password_Field.setText("");
        phoneNumber_TextField.setText("");
    }
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        ViewAdminAccount  viewAdminAccountModule = new ViewAdminAccount();
        
        String acc_Name = name_TextField.getText();  
        String acc_Email = email_TextField.getText();
        String acc_Phone_Number = phoneNumber_TextField.getText();  
        String acc_Username = username_TextField.getText();
        String acc_Password = String.valueOf(password_Field.getPassword());
        
        String regEx_Name = "^[A-Za-z\\s'-]+, [A-Za-z\\s'-]+$";
        String regEx_Email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        String regEx_PhoneNumber = "^09\\d{9}$";

        Pattern pattern_Name = Pattern.compile(regEx_Name);
        Pattern pattern_Email = Pattern.compile(regEx_Email);
        Pattern pattern_PhoneNumber = Pattern.compile(regEx_PhoneNumber);
    
        Matcher matcher_Name = pattern_Name.matcher(acc_Name);
        Matcher matcher_Email = pattern_Email.matcher(acc_Email);
        Matcher matcher_PhoneNumber = pattern_PhoneNumber.matcher(acc_Phone_Number);
        
        
        int account = 0;
        
        for (int i = 0; i < ViewAdminAccount.viewAdminAccountList_Table.getRowCount(); i++)
        {
            
            if (acc_Username.equalsIgnoreCase(viewAdminAccountList_Table.getValueAt(i, 3).toString()))
            {
                account++;  
            }
        }
                if (name_TextField.getText().equals("") || email_TextField.getText().equals("") || phoneNumber_TextField.getText().equals("") || username_TextField.getText().equals("") || password_Field.getText().equals("")) 
                {
                    JOptionPane.showMessageDialog(null, "Kindly fill out the field.", "Error: Missing Field", JOptionPane.ERROR_MESSAGE);
                    clearFields();   
                }
                else if (!matcher_Name.matches())
                {
                     JOptionPane.showMessageDialog(null, "Name is formatted incorrectly.", "Error: Invalid Name Format", JOptionPane.ERROR_MESSAGE);
                     name_TextField.setText("");
                }
                else if (!matcher_Email.matches())
                {
                    JOptionPane.showMessageDialog(null, "Email is formatted incorrectly.", "Error: Invalid Email Format",JOptionPane.ERROR_MESSAGE);
                    email_TextField.setText("");
                }
                else if (!matcher_PhoneNumber.matches())
                {
                    JOptionPane.showMessageDialog(null, "Contact Number is formatted incorrectly.", "Error: Invalid Contact Number Format", JOptionPane.ERROR_MESSAGE);
                    phoneNumber_TextField.setText("");
                }
                else if (account != 0)
                {
                    JOptionPane.showMessageDialog(null, "The username " + acc_Username + "  is already exists.", "Warning: Username Already Taken", JOptionPane.WARNING_MESSAGE);
                    username_TextField.setText("");
                }
                else 
                {
                    int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to create account?","Register",JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION)
                    {
                        try 
                        {
                            String queryRegister = "INSERT INTO registration_database (Name,Email,PhoneNumber,Username,Password) VALUES ('"+acc_Name+"', '"+acc_Email+"', '"+acc_Phone_Number+"', '"+acc_Username+"', '"+acc_Password+"')";
                            st.execute(queryRegister );
                            JOptionPane.showMessageDialog(new JFrame(), "Register Successfully.", "Account Created",JOptionPane.INFORMATION_MESSAGE);
                            clearFields();
                            
                            viewAdminAccountModule.setVisible(true);
                            dispose();
                        }
                        catch (SQLException ex) 
                        {
                            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error adding profile", ex);
                            JOptionPane.showMessageDialog(null, "An error occurred while adding the profile. Please try again later.", "Error", JOptionPane.ERROR_MESSAGE);
                            clearFields();
                        } 
                    }
                    else if (choice == JOptionPane.NO_OPTION)
                    {
                        JOptionPane.showMessageDialog(new JFrame(), "Creating an account cancelled.","Registration canceled",JOptionPane.ERROR_MESSAGE);
                        clearFields();
                    }     
                }
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);

        password_Field.setEchoChar ((char)0);
    }//GEN-LAST:event_show_IconMousePressed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);

        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input numbers only.", "Error: Numbers Only",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
       
        JOptionPane.showMessageDialog(null, "The application will be closed", "Exit Application", JOptionPane.INFORMATION_MESSAGE );
        
    }//GEN-LAST:event_formWindowClosing


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addAccount_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JLabel email_Icon;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel key_Icon;
    private javax.swing.JLabel name_Label;
    private javax.swing.JTextField name_TextField;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel phone_Icon;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Icon;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
