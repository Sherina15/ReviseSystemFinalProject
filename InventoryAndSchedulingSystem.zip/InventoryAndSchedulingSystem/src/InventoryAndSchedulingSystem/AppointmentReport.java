package InventoryAndSchedulingSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.DecimalFormat;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;

public class AppointmentReport extends javax.swing.JFrame {


    public AppointmentReport() 
    {
        initComponents();
        
        try 
        {
            tableUpdate();
            total();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AppointmentReport.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";    
   
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);   
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        appointmentReport_Label = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        appointmentReport_ScrollPane = new javax.swing.JScrollPane();
        appointmentReport_Table = new javax.swing.JTable();
        back_Button = new javax.swing.JButton();
        searchBar_TextField = new javax.swing.JTextField();
        totalPrice_Label = new javax.swing.JLabel();
        price_Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("APPOINTMENT REPORT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        appointmentReport_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        appointmentReport_Label.setForeground(new java.awt.Color(255, 255, 255));
        appointmentReport_Label.setText("Appointment Report");

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(appointmentReport_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(appointmentReport_Label)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        appointmentReport_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Owner's Name", "Pet's Name ", "Contact No.", "Service Type", "Pet's Size", "Price", "Time", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        appointmentReport_Table.getTableHeader().setReorderingAllowed(false);
        appointmentReport_ScrollPane.setViewportView(appointmentReport_Table);
        if (appointmentReport_Table.getColumnModel().getColumnCount() > 0) {
            appointmentReport_Table.getColumnModel().getColumn(0).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(1).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(2).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(3).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(4).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(5).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(6).setResizable(false);
            appointmentReport_Table.getColumnModel().getColumn(7).setResizable(false);
        }

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Close");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBar_TextFieldActionPerformed(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });

        totalPrice_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totalPrice_Label.setText("Total Price:₱");

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(top_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(totalPrice_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(whole_PanelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(back_Button))
                            .addGroup(whole_PanelLayout.createSequentialGroup()
                                .addComponent(price_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(appointmentReport_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 900, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchBar_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(searchBar_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(appointmentReport_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addContainerGap())
                    .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(totalPrice_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(price_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    static int selectedRowIndex;
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM appointmentreport_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)appointmentReport_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Owner_Name"));
                    vec.add(rs.getString("Pet_Name"));
                    vec.add(rs.getString("ContactNumber"));
                    vec.add(rs.getString("ServiceType"));
                    vec.add(rs.getString("PetSize"));
                    vec.add(rs.getString("Price"));
                    vec.add(rs.getString("Time"));
                    vec.add(rs.getString("Date"));
                    
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
     private void total()throws SQLException
    {
        DefaultTableModel dtm = (DefaultTableModel)appointmentReport_Table.getModel();
        
        String price;
        String formatPrice;
        String subTotal;
        
        int intNumQuantity = 0;
        double dblPrice = 0.00;
        
        double priceTotal = 0.00;
        double dblSubTotal = 0.00;
        double totalPrice = 0.00;
        double SubTotalPrice = 0.00;
        
        String formatSubTotal;
            
        for(int i = 0; i < appointmentReport_Table.getRowCount(); i++)
        {
            price =  appointmentReport_Table.getValueAt(i, 5).toString();
            price = price.replace(",", "");
            
            dblPrice = Double.parseDouble(price);
            
            JOptionPane.showMessageDialog(null, dblPrice );
            
            
            DecimalFormat priceFormat=new DecimalFormat("#,###.00");
            formatPrice = priceFormat.format(dblPrice);
            dtm.setValueAt(formatPrice, i, 5);
        }
        
        for(int i = 0; i < appointmentReport_Table.getRowCount(); i++)
        {
            subTotal =  appointmentReport_Table.getValueAt(i, 5).toString();
            subTotal = subTotal.replace(",", "");            
            
            dblSubTotal = Double.parseDouble(subTotal);
            
            SubTotalPrice = dblSubTotal + SubTotalPrice;
            
            DecimalFormat subTotalFormat=new DecimalFormat("#,###.00");
            formatSubTotal = subTotalFormat.format(SubTotalPrice);
            price_Label.setText(formatSubTotal);  
        }    
    }
  
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
    }//GEN-LAST:event_formWindowClosing

    private void searchBar_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBar_TextFieldActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) appointmentReport_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        appointmentReport_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldActionPerformed

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
       if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
       if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) appointmentReport_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        appointmentReport_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AppointmentReport.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppointmentReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel appointmentReport_Label;
    private javax.swing.JScrollPane appointmentReport_ScrollPane;
    private javax.swing.JTable appointmentReport_Table;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel totalPrice_Label;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
