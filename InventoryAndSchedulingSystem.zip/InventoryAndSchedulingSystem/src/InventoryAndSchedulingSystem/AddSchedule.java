package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewSchedule.viewSchedule_Table;
import java.util.Date;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddSchedule extends javax.swing.JFrame {

    public AddSchedule() 
    {

        initComponents();
        
        Date currentDate = new Date(); 
        currentDate.setDate(currentDate.getDate()+1);
        dateChooser.setMinSelectableDate(currentDate);
        price_TextField.setEditable(false);

        try 
        {
            Connection();
             
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AddSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        addSchedule_Label = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        lower_Panel = new javax.swing.JPanel();
        personalInfo_Label = new javax.swing.JLabel();
        ownerName_Label = new javax.swing.JLabel();
        ownerName_TextField = new javax.swing.JTextField();
        petName_Label = new javax.swing.JLabel();
        petName_TextField = new javax.swing.JTextField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        date_Label = new javax.swing.JLabel();
        time_Label = new javax.swing.JLabel();
        time_ComboBox = new javax.swing.JComboBox<>();
        petSize_Label = new javax.swing.JLabel();
        petSize_ComboBox = new javax.swing.JComboBox<>();
        serviceType_Label = new javax.swing.JLabel();
        serviceType_ComboBox = new javax.swing.JComboBox<>();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        add_Button = new javax.swing.JButton();
        dateChooser = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD SCHEDULE");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        addSchedule_Label.setText("ADD SCHEDULE");
        addSchedule_Label.setBackground(new java.awt.Color(0, 0, 0));
        addSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        addSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));
        whole_Panel.add(addSchedule_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 41, -1, -1));

        back_Button.setText("Back");
        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(back_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));
        lower_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        personalInfo_Label.setText("PERSONAL INFORMATION");
        personalInfo_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lower_Panel.add(personalInfo_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 6, -1, -1));

        ownerName_Label.setText("Owner's Name");
        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(ownerName_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 37, -1, -1));

        ownerName_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ownerName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lower_Panel.add(ownerName_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 63, 330, 30));

        petName_Label.setText("Pet's Name");
        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(petName_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 103, -1, -1));

        petName_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        petName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        petName_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                petName_TextFieldKeyTyped(evt);
            }
        });
        lower_Panel.add(petName_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 129, 330, 30));

        phoneNumber_Label.setText("Contact No.");
        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 165, -1, -1));

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        lower_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 191, 330, 30));

        date_Label.setText("Date");
        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(date_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 227, -1, -1));

        time_Label.setText("Time:");
        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(time_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, -1, -1));

        time_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        time_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "8:00 am - 10:00 am", "10:00 am -12:00 pm", "1:00 pm - 3:00 pm", "3:00 pm - 5:00 pm" }));
        time_ComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        time_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_ComboBoxActionPerformed(evt);
            }
        });
        lower_Panel.add(time_ComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 330, 30));

        petSize_Label.setText("Pet's Size");
        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(petSize_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        petSize_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        petSize_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "    ", "Small Breed", "Medium Breed", "Large Breed" }));
        petSize_ComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        petSize_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                petSize_ComboBoxActionPerformed(evt);
            }
        });
        lower_Panel.add(petSize_ComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 330, 30));

        serviceType_Label.setText("Service Type");
        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(serviceType_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        serviceType_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        serviceType_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "Full Groom", "Ear Cleaning & Nail Trimming", "Face Trim + Body Trim", "Sanitary  + Face Trim", "Ear Cleaning", "Sanitary Cleaning", "Face Trim", "Nail Clipping", "Bath & Blowdry" }));
        serviceType_ComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        serviceType_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serviceType_ComboBoxActionPerformed(evt);
            }
        });
        lower_Panel.add(serviceType_ComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 330, 30));

        price_Label.setText("Price");
        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lower_Panel.add(price_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, -1, -1));

        price_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        price_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lower_Panel.add(price_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 330, 30));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add");
        add_Button.setToolTipText("Add Schedule");
        add_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        lower_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 550, 100, 26));

        dateChooser.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        dateChooser.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lower_Panel.add(dateChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 330, 30));

        whole_Panel.add(lower_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 400, 590));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void tableUpdate() throws SQLException
    {
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM schedule_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)viewSchedule_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Owner_Name"));
                    vec.add(rs.getString("Pet_Name"));
                    vec.add(rs.getString("ContactNumber"));
                    vec.add(rs.getString("ServiceType"));
                    vec.add(rs.getString("PetSize"));
                    vec.add(rs.getString("Price"));
                    vec.add(rs.getString("Time"));
                    vec.add(rs.getString("Date"));
                    
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void clearFields()
    {
        
        ownerName_TextField.setText("");
        petName_TextField.setText("");
        phoneNumber_TextField.setText("");
        dateChooser.setDate(null);
        price_TextField.setText("");
        
    }
    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        
        String Schedule_Owner = ownerName_TextField.getText();
        String Schedule_Pet = petName_TextField.getText();
        String Schedule_ContactNumber = phoneNumber_TextField.getText();
        Date date = dateChooser.getDate();
        String Schedule_Time = (String) time_ComboBox.getSelectedItem();
        String Schedule_ServiceType = (String) serviceType_ComboBox.getSelectedItem();
        String Schedule_PetSize = (String) petSize_ComboBox.getSelectedItem();
        String Schedule_Price = price_TextField.getText();
        
        String regEx_Owner = "^[A-Za-z\\s'-]+, [A-Za-z\\s'-]+$";
        String regEx_PhoneNumber = "^09\\d{9}$";
        
        Pattern pattern_Name = Pattern.compile(regEx_Owner);
        Pattern pattern_PhoneNumber = Pattern.compile(regEx_PhoneNumber);
        
        Matcher matcher_Name = pattern_Name.matcher(Schedule_Owner);
        Matcher matcher_PhoneNumber = pattern_PhoneNumber.matcher(Schedule_ContactNumber);
        
         DecimalFormat decFormat=new DecimalFormat("0.00");

        int schedule = 0;
           
        if (ownerName_TextField.getText().equals("")||petName_TextField.equals("")|| phoneNumber_TextField.getText().equals("")||dateChooser.getDate().equals(" ")|| time_ComboBox.getSelectedItem().equals("  ")||serviceType_ComboBox.getSelectedItem().equals("  ")||petSize_ComboBox.getSelectedItem().equals("  ")||price_TextField.getText().equals("")){
           JOptionPane.showMessageDialog(null, "Empty fields.", "Error: Missing Field",JOptionPane.ERROR_MESSAGE);
                        clearFields(); 
        }
        else{
        
        
        
        try 
            { 
                int choice = JOptionPane.showConfirmDialog (null,"Are you sure you want to add " + petName_TextField.getText() + "?" , "Add Record ",JOptionPane.YES_NO_OPTION);
                
                if (choice == JOptionPane.CANCEL_OPTION)
                {    
                        JOptionPane.showMessageDialog(null, "Adding reservation was Unsucessful","Unsuccessful",JOptionPane.ERROR_MESSAGE); 
                        clearFields();
                }
                else if (choice == JOptionPane.YES_OPTION) 
                { 
                    SimpleDateFormat dateFormat =new SimpleDateFormat("dd-MMM-yyyy"); 
                    String dateRecord =  dateFormat.format(dateChooser.getDate());
                    
                    double product_Amount = Double.parseDouble(Schedule_Price);
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
        
                    String fproduct_Amount= (formatter.format(product_Amount));
                    
                    for (int i = 0; i < viewScheduleModule.viewSchedule_Table.getRowCount(); i++)
                    {
                        if (Schedule_Pet.equalsIgnoreCase(viewSchedule_Table.getValueAt(i, 1).toString()) && Schedule_Owner.equalsIgnoreCase(viewSchedule_Table.getValueAt(i, 0).toString()) && dateRecord.equals(viewSchedule_Table.getValueAt(i, 7).toString()))
                        {
                            schedule++;  
                        }    
                    }  
                    
                    if (ownerName_TextField.getText().equals("")|| petName_TextField.getText().equals("")|| phoneNumber_TextField.getText().equals("") || date == null || time_ComboBox.getSelectedItem().equals("  ")|| serviceType_ComboBox.getSelectedItem().equals("  ") || petSize_ComboBox.getSelectedItem().equals("    ")||price_TextField.getText().equals("") )
                    {    
                        JOptionPane.showMessageDialog(null, "Empty fields.", "Error: Missing Field",JOptionPane.ERROR_MESSAGE);
                        clearFields();
                    }
                    else if (time_ComboBox.getSelectedItem().equals("")){
                        
                        JOptionPane.showMessageDialog(null, "Invalid Time.","Error: Invalid Time",JOptionPane.ERROR_MESSAGE);
                        time_ComboBox.isFocusable();
                        clearFields();
                    }
                    else if (!matcher_Name.matches())
                    {
                        JOptionPane.showMessageDialog(null, "Owner is formatted incorrectly.", "Error: Invalid Name Format",JOptionPane.ERROR_MESSAGE);
                        ownerName_TextField.setText("");
                    }
                    else if (!matcher_PhoneNumber.matches())
                    {
                        JOptionPane.showMessageDialog(null, "Phone number is formatted incorrectly.", "Error: Invalid Phone Number Format",JOptionPane.ERROR_MESSAGE);
                        phoneNumber_TextField.setText("");
                    }
                    else if (schedule != 0)
                    {
                        JOptionPane.showMessageDialog(null, "The client is already scheduled for this day.", "Reserved",JOptionPane.ERROR_MESSAGE);
                        clearFields();  
                    }
                    
                    else
                    {  
                    String queryRegister = "INSERT INTO schedule_database (Owner_Name,Pet_Name,ContactNumber,ServiceType,PetSize,Price,Time,Date) VALUES ('"+Schedule_Owner+"', '"+Schedule_Pet+"', '"+Schedule_ContactNumber+"','"+Schedule_ServiceType+"', '"+Schedule_PetSize+"', '"+fproduct_Amount+"','"+Schedule_Time+"','"+dateRecord+"')";
                    pst = con.prepareStatement(queryRegister);

                    int rowsAffected = pst.executeUpdate();
                    
                        if (rowsAffected > 0) 
                        {
                            JOptionPane.showMessageDialog(null, "Reservation added successfully."," Added Successfully",JOptionPane.INFORMATION_MESSAGE); 
                            clearFields(); 
                            viewScheduleModule.setVisible(true);
                            dispose();
                        } 
                        else 
                        {
                        JOptionPane.showMessageDialog(null, "Failed to Add Reservation.", "Error", JOptionPane.ERROR_MESSAGE);
                        clearFields();
                        }
                    }
                }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error adding record profile", ex);
                JOptionPane.showMessageDialog(null, "An error occurred while adding record. Please try again later.","Error",JOptionPane.ERROR_MESSAGE);
                clearFields();
            }
        }
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AddSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        JOptionPane.showMessageDialog(null, "The application will be closed.","Exit Application",JOptionPane.INFORMATION_MESSAGE );
    }//GEN-LAST:event_formWindowClosing

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void serviceType_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serviceType_ComboBoxActionPerformed
        Object serviceType = serviceType_ComboBox.getSelectedItem();
        Object petSize = petSize_ComboBox.getSelectedItem();
   
    if (serviceType != null && petSize != null) 
    {
        String serviceTypeStr = serviceType.toString();
        String petSizeStr = petSize.toString();
        
//FullGroom
    if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Small Breed")) 
    {
        price_TextField.setText("450");
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("580");        
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("850");        
    }   
//Ear Cleaning & Nail Trimming   
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("220");        
    }
//Face Trim + Body Trim
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("400");        
    }
//Sanitary  + Face Trim
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }
//Ear Cleaning  
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Sanitary Cleaning
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Face Trim
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Nail Clipping
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Bath & Blowdry
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }  
    else 
    {
        price_TextField.setText(""); 
    }
}
    }//GEN-LAST:event_serviceType_ComboBoxActionPerformed

    private void petSize_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_petSize_ComboBoxActionPerformed
        Object serviceType = serviceType_ComboBox.getSelectedItem();
        Object petSize = petSize_ComboBox.getSelectedItem();
  
    if (serviceType != null && petSize != null) 
    {
        String serviceTypeStr = serviceType.toString();
        String petSizeStr = petSize.toString();
//FullGroom
    if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Small Breed")) 
    {
        price_TextField.setText("450");
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("580");        
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("850");        
    }   
//Ear Cleaning & Nail Trimming   
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("220");        
    }
//Face Trim + Body Trim
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("400");        
    }
//Sanitary  + Face Trim
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }
//Ear Cleaning  
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Sanitary Cleaning
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Face Trim
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Nail Clipping
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Bath & Blowdry
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }
    
    else 
    {
        price_TextField.setText(""); 
    }
    }
    }//GEN-LAST:event_petSize_ComboBoxActionPerformed

    private void petName_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_petName_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isDigit(c) || (c==KeyEvent.VK_SPACE) || (c==KeyEvent.VK_DELETE) || (c==KeyEvent.VK_PERIOD)|| (c==KeyEvent.VK_BACK_SLASH))
        {
            JOptionPane.showMessageDialog(null, "Text only");
            getToolkit().beep();
            evt.consume();
            
        }
    }//GEN-LAST:event_petName_TextFieldKeyTyped

    private void time_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_ComboBoxActionPerformed
        
        ViewSchedule viewScheduleModule = new ViewSchedule();
        SimpleDateFormat dateFormat =new SimpleDateFormat("dd-MMM-yyyy"); 
        String dateRecord =  dateFormat.format(dateChooser.getDate());
        
     
        int counter = 0;
        
        for(int i=0; i < ViewSchedule.viewSchedule_Table.getRowCount(); i++)
        { 
            String time = viewSchedule_Table.getValueAt(i, 6).toString();
            String date = viewSchedule_Table.getValueAt(i, 7).toString();
            
           for(int timeCounter =0; timeCounter < time_ComboBox.getItemCount(); timeCounter++)
           {
            if (dateRecord.equals(date) && time_ComboBox.getItemAt(timeCounter).equals(time))
             {
                counter++;
                break;
             }           
           }    
        }
        if (counter == 4)
           {
               JOptionPane.showMessageDialog(null, "We are fully booked in this date. Please select another date.","Pick Another Date",JOptionPane.INFORMATION_MESSAGE);
                 Date currentDate = new Date(); 
                 currentDate.setDate(currentDate.getDate()+1);
                 dateChooser.setDate(null);
                 time_ComboBox.setSelectedIndex(0);
                 dateChooser.isFocusable();    
           }
        for(int i=0; i < ViewSchedule.viewSchedule_Table.getRowCount(); i++)
        { 
            String time = viewSchedule_Table.getValueAt(i, 6).toString();
            String date = viewSchedule_Table.getValueAt(i, 7).toString();

           if (time_ComboBox.getSelectedItem().equals(time) && dateRecord.equals(date))
            {
               time_ComboBox.setSelectedIndex(0);
               JOptionPane.showMessageDialog(null, "You cannot pick this time, already reserved. Please select another Time.","Pick Another Time",JOptionPane.INFORMATION_MESSAGE);
               time_ComboBox.isFocusable();
               break;
            }    
        }
          
    }//GEN-LAST:event_time_ComboBoxActionPerformed

    private void dateChooser(){
        ViewSchedule viewScheduleModule = new ViewSchedule();
        SimpleDateFormat dateFormat =new SimpleDateFormat("dd-MMM-yyyy"); 
        String dateRecord =  dateFormat.format(dateChooser.getDate());
        
        int counter = 0;
        
        for(int i=0; i < ViewSchedule.viewSchedule_Table.getRowCount(); i++)
        { 
            String time = viewSchedule_Table.getValueAt(i, 6).toString();
            String date = viewSchedule_Table.getValueAt(i, 7).toString();
            
           for(int timeCounter =0; timeCounter < time_ComboBox.getItemCount(); timeCounter++)
           {
            if (dateRecord.equals(date) && time_ComboBox.getItemAt(timeCounter).equals(time))
             {
                counter++;
                 break;
             }           
           }    
        }
        if (counter == 4)
           {
               JOptionPane.showMessageDialog(null, "We are fully booked in this date. Please select another date.","Pick Another Date",JOptionPane.INFORMATION_MESSAGE);
                 Date currentDate = new Date(); 
                 currentDate.setDate(currentDate.getDate()+1);
                 dateChooser.setMinSelectableDate(currentDate);
                 dateChooser.setDate(currentDate);
                 dateChooser.isFocusable();
           }
    }
    
    
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addSchedule_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JLabel date_Label;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JLabel ownerName_Label;
    private javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel personalInfo_Label;
    private javax.swing.JLabel petName_Label;
    private javax.swing.JTextField petName_TextField;
    private javax.swing.JComboBox<String> petSize_ComboBox;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JComboBox<String> serviceType_ComboBox;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JComboBox<String> time_ComboBox;
    private javax.swing.JLabel time_Label;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
