package InventoryAndSchedulingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class UpdateSchedule extends javax.swing.JFrame {

    public UpdateSchedule() 
    {
        initComponents();
        
        ownerName_TextField.setEditable(false);
        phoneNumber_TextField.setEditable(false);
        petName_TextField.setEditable(false);
        dateChooser_TextField.setEditable(false);
        price_TextField.setEditable(false);
        petSize_ComboBox.disable();
        time_TextField.setEditable(false);
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        updateSchedule_Label = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        petName_Label = new javax.swing.JLabel();
        petName_TextField = new javax.swing.JTextField();
        ownerName_Label = new javax.swing.JLabel();
        ownerName_TextField = new javax.swing.JTextField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        petSize_Label = new javax.swing.JLabel();
        petSize_ComboBox = new javax.swing.JComboBox<>();
        serviceType_Label = new javax.swing.JLabel();
        serviceType_ComboBox = new javax.swing.JComboBox<>();
        date_Label = new javax.swing.JLabel();
        time_Label = new javax.swing.JLabel();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        update_Button = new javax.swing.JButton();
        clientInfo_Label = new javax.swing.JLabel();
        dateChooser_TextField = new javax.swing.JTextField();
        time_TextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("UPDATE SCHEDULE");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setPreferredSize(new java.awt.Dimension(400, 600));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        updateSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        updateSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));
        updateSchedule_Label.setText("Update Schedule");

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(updateSchedule_Label)
                    .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateSchedule_Label)
                        .addGap(0, 4, Short.MAX_VALUE)))
                .addContainerGap())
        );

        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        petName_Label.setText("Pet's Name");

        petName_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        petName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ownerName_Label.setText("Owner's Name");

        ownerName_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ownerName_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Contact Number");

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        petSize_Label.setText("Pet's Size ");

        petSize_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        petSize_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "Small Breed", "Medium Breed", "Large Breed" }));
        petSize_ComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        petSize_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                petSize_ComboBoxActionPerformed(evt);
            }
        });

        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        serviceType_Label.setText("Service Type");

        serviceType_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        serviceType_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "Full Groom", "Ear Cleaning & Nail Trimming", "Face Trim + Body Trim", "Sanitary  + Face Trim", "Ear Cleaning", "Sanitary Cleaning", "Face Trim", "Nail Clipping", "Bath & Blowdry" }));
        serviceType_ComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        serviceType_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serviceType_ComboBoxActionPerformed(evt);
            }
        });

        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        date_Label.setText("Date");

        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time_Label.setText("Time");

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");

        price_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        price_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        update_Button.setBackground(new java.awt.Color(204, 204, 204));
        update_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        update_Button.setText("Save");
        update_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        update_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_ButtonActionPerformed(evt);
            }
        });

        clientInfo_Label.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        clientInfo_Label.setText("CLIENT PERSONAL INFORMATION");

        dateChooser_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        dateChooser_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        time_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        time_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(top_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(clientInfo_Label))
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(price_Label)
                            .addComponent(petSize_Label)
                            .addComponent(serviceType_Label)
                            .addComponent(phoneNumber_Label)
                            .addComponent(phoneNumber_TextField)
                            .addComponent(date_Label)
                            .addComponent(time_Label)
                            .addComponent(serviceType_ComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(petSize_ComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(price_TextField)
                            .addComponent(petName_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                            .addComponent(ownerName_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                            .addComponent(petName_Label)
                            .addComponent(ownerName_Label)
                            .addComponent(update_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateChooser_TextField)
                            .addComponent(time_TextField))))
                .addGap(0, 25, Short.MAX_VALUE))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clientInfo_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ownerName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ownerName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_Label)
                .addGap(8, 8, 8)
                .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dateChooser_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(time_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(time_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(serviceType_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petSize_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petSize_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(update_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        EditSchedule editScheduleModule = new EditSchedule();
        editScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void update_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_ButtonActionPerformed
       EditSchedule editScheduleModule =  new EditSchedule();
       
       DecimalFormat decFormat=new DecimalFormat("0.00");
        
        String Schedule_Owner = ownerName_TextField.getText();
        String Schedule_Pet = petName_TextField.getText();
        String Schedule_ContactNumber = phoneNumber_TextField.getText();
        String Schedule_Date = dateChooser_TextField.getText();
        String Schedule_Time = time_TextField.getText();
        String Schedule_ServiceType = (String) serviceType_ComboBox.getSelectedItem();
        String Schedule_PetSize = (String) petSize_ComboBox.getSelectedItem();
        String Schedule_Price = price_TextField.getText();

        if (ownerName_TextField.getText().equals("")|| petName_TextField.getText().equals("")||dateChooser_TextField.getText().equals("")||time_TextField.getText().equals("")||serviceType_ComboBox.getSelectedItem().equals("  ")||petSize_ComboBox.getSelectedItem().equals("  ")||price_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Invalid Input", "Update", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
           int choice = JOptionPane.showConfirmDialog(this, "Do you want to update?", "Update", JOptionPane.YES_NO_OPTION);
           
           if (choice == JOptionPane.YES_OPTION) 
           {
                    double product_Amount = Double.parseDouble(Schedule_Price);
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
        
                    String fproduct_Amount= (formatter.format(product_Amount));
               try
               {
                    Class.forName(dbDriver);
                    Connection con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                    String sql = "UPDATE schedule_database SET ServiceType=?, Price=? WHERE Owner_Name=? AND Pet_Name=? AND Date=?";
                    PreparedStatement updateStmt = con.prepareStatement(sql);
                        
                        updateStmt.setString(1, Schedule_ServiceType);
                        updateStmt.setString(2, fproduct_Amount);
                        updateStmt.setString(3, Schedule_Owner);
                        updateStmt.setString(4, Schedule_Pet);
                        updateStmt.setString(5, Schedule_Date); 

                        int rowsUpdated = updateStmt.executeUpdate();

                        if (rowsUpdated > 0) 
                        {
                            JOptionPane.showMessageDialog(this, "Record Updated Successfully", "Update", JOptionPane.INFORMATION_MESSAGE);

                            ViewSchedule viewScheduleModule = new ViewSchedule();
                            viewScheduleModule.setVisible(true);
                            dispose(); 
                        } 
                        else 
                        {
                            JOptionPane.showMessageDialog(this, "Failed to update record", "Update", JOptionPane.ERROR_MESSAGE);
                        }
               }
               catch(Exception e)
               {
                   JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
               }
           }
           else if (choice == JOptionPane.NO_OPTION)
           {
            JOptionPane.showMessageDialog(this, "Cancel", "Update", JOptionPane.ERROR_MESSAGE);   
           }
        }  
    }//GEN-LAST:event_update_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
    
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    private void serviceType_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serviceType_ComboBoxActionPerformed
        Object serviceType = serviceType_ComboBox.getSelectedItem();
        Object petSize = petSize_ComboBox.getSelectedItem();
   
    if (serviceType != null && petSize != null) 
    {
        String serviceTypeStr = serviceType.toString();
        String petSizeStr = petSize.toString();
        
//FullGroom
    if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Small Breed")) 
    {
        price_TextField.setText("450");
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("580");        
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("850");        
    }   
//Ear Cleaning & Nail Trimming   
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("220");        
    }
//Face Trim + Body Trim
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("400");        
    }
//Sanitary  + Face Trim
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }
//Ear Cleaning  
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Sanitary Cleaning
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Face Trim
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Nail Clipping
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Bath & Blowdry
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }  
    else 
    {
        price_TextField.setText(""); 
    }
}
    }//GEN-LAST:event_serviceType_ComboBoxActionPerformed

    private void petSize_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_petSize_ComboBoxActionPerformed
        Object serviceType = serviceType_ComboBox.getSelectedItem();
        Object petSize = petSize_ComboBox.getSelectedItem();
   
    if (serviceType != null && petSize != null) 
    {
        String serviceTypeStr = serviceType.toString();
        String petSizeStr = petSize.toString();
        
//FullGroom
    if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Small Breed")) 
    {
        price_TextField.setText("450");
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("580");        
    }
    else if (serviceTypeStr.equals("Full Groom") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("850");        
    }   
//Ear Cleaning & Nail Trimming   
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("220");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning & Nail Trimming") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("220");        
    }
//Face Trim + Body Trim
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("400");        
    }
    else if (serviceTypeStr.equals("Face Trim + Body Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("400");        
    }
//Sanitary  + Face Trim
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Sanitary  + Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }
//Ear Cleaning  
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Ear Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Sanitary Cleaning
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Sanitary Cleaning") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Face Trim
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("150");        
    }
    else if (serviceTypeStr.equals("Face Trim") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("150");        
    }
//Nail Clipping
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("120");        
    }
    else if (serviceTypeStr.equals("Nail Clipping") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("120");        
    }
//Bath & Blowdry
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Small Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Medium Breed"))
    {
        price_TextField.setText("250");        
    }
    else if (serviceTypeStr.equals("Bath & Blowdry") && petSizeStr.equals("Large Breed"))
    {
        price_TextField.setText("250");        
    }  
    else 
    {
        price_TextField.setText(""); 
    }
}
    }//GEN-LAST:event_petSize_ComboBoxActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientInfo_Label;
    private javax.swing.JLabel clientShop_Logo;
    public static javax.swing.JTextField dateChooser_TextField;
    private javax.swing.JLabel date_Label;
    private javax.swing.JLabel ownerName_Label;
    public static javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel petName_Label;
    public static javax.swing.JTextField petName_TextField;
    public static javax.swing.JComboBox<String> petSize_ComboBox;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JLabel phoneNumber_Label;
    public static javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    public static javax.swing.JTextField price_TextField;
    public static javax.swing.JComboBox<String> serviceType_ComboBox;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JLabel time_Label;
    public static javax.swing.JTextField time_TextField;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel updateSchedule_Label;
    private javax.swing.JButton update_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
