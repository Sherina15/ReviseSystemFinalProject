package InventoryAndSchedulingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class ProductList extends javax.swing.JFrame {

    public ProductList() 
    {
        initComponents();
        
        productName_TextField.setEditable(false);
        price_TextField.setEditable(false);
        category_TextField.setEditable(false);
        
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(ProductList.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";

    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        stocks_Label = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        stocks_ScrollPane = new javax.swing.JScrollPane();
        stocks_Table = new javax.swing.JTable();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        productName_Label = new javax.swing.JLabel();
        productName_TextField = new javax.swing.JTextField();
        quantity_Label = new javax.swing.JLabel();
        category_Label = new javax.swing.JLabel();
        save_Button = new javax.swing.JButton();
        category_TextField = new javax.swing.JTextField();
        quantity_TextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("PRODUCT LIST");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        stocks_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        stocks_Label.setForeground(new java.awt.Color(255, 255, 255));
        stocks_Label.setText("Stocks");

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(stocks_Label)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(16, 16, 16))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(stocks_Label))
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(clientShop_Logo)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        stocks_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product Name", "Price", "Quantity", "Category"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        stocks_Table.getTableHeader().setReorderingAllowed(false);
        stocks_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stocks_TableMouseClicked(evt);
            }
        });
        stocks_ScrollPane.setViewportView(stocks_Table);
        if (stocks_Table.getColumnModel().getColumnCount() > 0) {
            stocks_Table.getColumnModel().getColumn(0).setResizable(false);
            stocks_Table.getColumnModel().getColumn(1).setResizable(false);
            stocks_Table.getColumnModel().getColumn(2).setResizable(false);
            stocks_Table.getColumnModel().getColumn(3).setResizable(false);
        }

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");

        productName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productName_Label.setText("Product Name");

        quantity_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantity_Label.setText("Quantity");

        category_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        category_Label.setText("Category");

        save_Button.setBackground(new java.awt.Color(204, 204, 204));
        save_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        save_Button.setText("Save");
        save_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        save_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_ButtonActionPerformed(evt);
            }
        });

        quantity_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                quantity_TextFieldKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("* This module will update the stock ");

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(top_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(stocks_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(save_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(productName_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                        .addComponent(quantity_Label)
                        .addComponent(category_Label)
                        .addComponent(productName_Label)
                        .addComponent(price_Label)
                        .addComponent(category_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                        .addComponent(price_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                        .addComponent(quantity_TextField))
                    .addComponent(jLabel1))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(productName_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quantity_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(quantity_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(category_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(category_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(save_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(jLabel1))
                    .addComponent(stocks_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    static int selectedRowIndex;

    private void tableUpdate() throws SQLException
    {
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM inventory_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)stocks_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Product_Name"));
                    vec.add(rs.getString("Product_Price"));
                    vec.add(rs.getString("Product_Quantity"));
                    vec.add(rs.getString("Product_Category"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ProductList.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public void clearFields()
        {
            productName_TextField.setText("");
            price_TextField.setText("");
            quantity_TextField.setText("");
            category_TextField.setText("");
        }
        
        
        
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
       MenuSystem menuSystemModule = new MenuSystem();
       menuSystemModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void stocks_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stocks_TableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel)stocks_Table.getModel();
        int selectedIndex = stocks_Table.getSelectedRow();

        selectedRowIndex = stocks_Table.getSelectedRow();
    
        productName_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        price_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        category_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
    }//GEN-LAST:event_stocks_TableMouseClicked

    
    private void save_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_ButtonActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) stocks_Table.getModel();
        int selectedIndex = stocks_Table.getSelectedRow(); 
               
        String Product_Quantity = quantity_TextField.getText();
            String Product_Name = productName_TextField.getText();
            String Product_Price = price_TextField.getText();
            String Product_Category = category_TextField.getText();
        
        
        if (selectedIndex != -1)
        {
            int numQuantity = Integer.parseInt(Product_Quantity);
            String itemQuantity;
            int itemFinalQuantity = 0;
            
            itemQuantity = stocks_Table.getValueAt(stocks_Table.getSelectedRow(), 2).toString();
            
            itemFinalQuantity = Integer.parseInt(itemQuantity);
            
            if (numQuantity <= 0)
            {
                    JOptionPane.showMessageDialog(null, "Please enter a valid quantity greater than zero.", "Invalid Quantity", JOptionPane.ERROR_MESSAGE);  
            }
            
            else if (itemFinalQuantity < numQuantity)
            {
                     JOptionPane.showMessageDialog(this, itemFinalQuantity);
                     JOptionPane.showMessageDialog(this, numQuantity);
                    JOptionPane.showMessageDialog(null, "Not enough items available.", "Insufficient Quantity", JOptionPane.WARNING_MESSAGE); 
            }
             
            else 
                {
                    int choice = JOptionPane.showConfirmDialog (null," Are you sure you to save" + "?" , "Add Record ",JOptionPane.YES_NO_OPTION);
 
                    if (choice == JOptionPane.YES_OPTION)
                    {
                        int checkQuantity = itemFinalQuantity -numQuantity;
                        
                        
                        if (checkQuantity == 0)
                            
                        {
                            try{
                            Class.forName(dbDriver);
                            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);  
                                    
                                    String queryRegister = "INSERT INTO inventoryreport_database (Product_Name, Product_Price, Product_Quantity, Product_Category) VALUES ('"+Product_Name+"','"+Product_Price+"','"+Product_Quantity+"','"+Product_Category+"')";
                                    insert = con.prepareStatement("DELETE FROM inventory_database WHERE Product_Name =? ");
                                    pst = con.prepareStatement(queryRegister);
                                    int rowsAffected = pst.executeUpdate();
                                    
                                    insert.setString(1, Product_Name);
                                    insert.executeUpdate(); 
                                    
                                    tableUpdate();
                                    clearFields();
                                    
                                    if (rowsAffected > 0 ) 
                                    {
                                        JOptionPane.showMessageDialog(null, "Profile added successfully","Added",JOptionPane.INFORMATION_MESSAGE);
                                    }
                                    else 
                                    {
                                        JOptionPane.showMessageDialog(null, "Failed to Add profile.");
                                        clearFields();
                                    }
                            }
                            catch(Exception e)
                            {
                                
                            }
                        }
                        else{
                        
                        try
                        {
                                String queryRegister = "INSERT INTO inventoryreport_database (Product_Name, Product_Price, Product_Quantity, Product_Category) VALUES ('"+Product_Name+"','"+Product_Price+"','"+Product_Quantity+"','"+Product_Category+"')";
                                PreparedStatement updateStmt = con.prepareStatement("UPDATE inventory_database SET Product_Quantity = Product_Quantity - ? WHERE Product_Name = ?");

                                pst = con.prepareStatement(queryRegister);
                                int rowsAffected = pst.executeUpdate();

                                updateStmt.setString(1, Product_Quantity);
                                updateStmt.setString(2, Product_Name);
                                int rowsUpdated = updateStmt.executeUpdate();

                                clearFields();
                                tableUpdate();

                                    if (rowsAffected > 0 && rowsUpdated > 0) 
                                    {
                                        JOptionPane.showMessageDialog(null, "Profile added successfully","Added",JOptionPane.INFORMATION_MESSAGE);
                                    }
                                    else 
                                    {
                                        JOptionPane.showMessageDialog(null, "Failed to Add profile.");
                                        clearFields();
                                    }
                                  
                        }
                        catch(Exception e)
                        {
                            
                        }
            
                    }    
                    }
            }
        }
        else 
        {
            JOptionPane.showMessageDialog(this, "Please select a row to update.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_save_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    private void quantity_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantity_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            quantity_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            quantity_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_quantity_TextFieldKeyTyped


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel category_Label;
    private javax.swing.JTextField category_TextField;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JLabel productName_Label;
    private javax.swing.JTextField productName_TextField;
    private javax.swing.JLabel quantity_Label;
    private javax.swing.JTextField quantity_TextField;
    private javax.swing.JButton save_Button;
    private javax.swing.JLabel stocks_Label;
    private javax.swing.JScrollPane stocks_ScrollPane;
    private javax.swing.JTable stocks_Table;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
