package InventoryAndSchedulingSystem;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import java.util.Base64;
import javax.swing.Timer;

public class MenuSystem extends javax.swing.JFrame {

    public MenuSystem() 
    {
        initComponents();
        
        startDateTimeUpdate();   
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        left_Panel = new javax.swing.JPanel();
        exit_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();
        list_Button = new javax.swing.JButton();
        inventory_Button = new javax.swing.JButton();
        schedule_Button = new javax.swing.JButton();
        productList_Button = new javax.swing.JButton();
        top_Panel = new javax.swing.JPanel();
        home_Label = new javax.swing.JLabel();
        logoutHome_Icon = new javax.swing.JLabel();
        facebook_Sabang = new javax.swing.JLabel();
        facebook_SanRafael = new javax.swing.JLabel();
        details_PhoneNumber = new javax.swing.JLabel();
        date_TextField = new javax.swing.JTextField();
        time_TextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MENU SYSTEM");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        left_Panel.setBackground(new java.awt.Color(255, 255, 255));
        left_Panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        exit_Button.setBackground(new java.awt.Color(204, 204, 204));
        exit_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exit_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        exit_Button.setText("Exit");
        exit_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        exit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/2x2_client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        list_Button.setBackground(new java.awt.Color(204, 204, 204));
        list_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        list_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_accountlist.png"))); // NOI18N
        list_Button.setText("Admin Account");
        list_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        list_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list_ButtonActionPerformed(evt);
            }
        });

        inventory_Button.setBackground(new java.awt.Color(204, 204, 204));
        inventory_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        inventory_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_inventory.png"))); // NOI18N
        inventory_Button.setText("Inventory ");
        inventory_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        inventory_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventory_ButtonActionPerformed(evt);
            }
        });

        schedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        schedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        schedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_calendar.png"))); // NOI18N
        schedule_Button.setText("   Schedule");
        schedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        schedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schedule_ButtonActionPerformed(evt);
            }
        });

        productList_Button.setBackground(new java.awt.Color(204, 204, 204));
        productList_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        productList_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_list.png"))); // NOI18N
        productList_Button.setText("Product List");
        productList_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        productList_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productList_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(list_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inventory_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(productList_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, left_PanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(clientShop_Name))
                    .addComponent(exit_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(schedule_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(clientShop_Logo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(clientShop_Logo)
                .addGap(18, 18, 18)
                .addComponent(clientShop_Name)
                .addGap(28, 28, 28)
                .addComponent(list_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(inventory_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(schedule_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productList_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(exit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        whole_Panel.add(left_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 610));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        home_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        home_Label.setForeground(new java.awt.Color(255, 255, 255));
        home_Label.setText("HOME");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(home_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(397, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(home_Label)
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 600, 100));

        logoutHome_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_logout.png"))); // NOI18N
        logoutHome_Icon.setToolTipText("Logout account");
        logoutHome_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutHome_IconMouseClicked(evt);
            }
        });
        whole_Panel.add(logoutHome_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 540, 50, 60));

        facebook_Sabang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        facebook_Sabang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_facebook.png"))); // NOI18N
        facebook_Sabang.setText("DeTails Pet Essentials and Lodging - Sabang");
        whole_Panel.add(facebook_Sabang, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 530, -1, -1));

        facebook_SanRafael.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        facebook_SanRafael.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_facebook.png"))); // NOI18N
        facebook_SanRafael.setText("DeTails San Rafael");
        whole_Panel.add(facebook_SanRafael, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 570, -1, -1));

        details_PhoneNumber.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        details_PhoneNumber.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        details_PhoneNumber.setText(" 09668764727");
        whole_Panel.add(details_PhoneNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, 130, 40));

        date_TextField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        date_TextField.setText("0");
        date_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(date_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 150, 150, 30));

        time_TextField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time_TextField.setText("0");
        time_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(time_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 110, 150, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    String storedPasswordHash = hashPassword("0000");
    
    private void startDateTimeUpdate() 
    {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

        Timer timer = new Timer(1000, e -> 
        {
            LocalDateTime now = LocalDateTime.now();
            date_TextField.setText(" DATE: " + dateFormatter.format(now));
            time_TextField.setText(" TIME: " + timeFormatter.format(now));
        });
            timer.start();
    }

    private static String hashPassword(String password) 
    {
        return Base64.getEncoder().encodeToString(password.getBytes());
    }
    
    private static boolean isPasswordCorrect(String enteredPassword, String storedPasswordHash) 
    { 
        String enteredPasswordHash = hashPassword(enteredPassword);
        return storedPasswordHash.equals(enteredPasswordHash);
    }
    
    private void exit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_ButtonActionPerformed
       int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit application?","Exit",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
       
       if (choice == JOptionPane.NO_OPTION )
       {
           
       }
       else
       {
            JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
            System.exit(0);
       }
    }//GEN-LAST:event_exit_ButtonActionPerformed

    private void list_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list_ButtonActionPerformed
        String enter = JOptionPane.showInputDialog(null, "Enter Password", "Verification", JOptionPane.PLAIN_MESSAGE);

        if (enter == null) 
        {
            JOptionPane.showMessageDialog(null, "Operation canceled by user");
        }
        
        else if (enter.isEmpty()) 
        {
            JOptionPane.showMessageDialog(null, "Please input password");   
        } else 
        {
            if (isPasswordCorrect(enter, storedPasswordHash)) 
            {
                JOptionPane.showMessageDialog(null, "Password correct!");
                ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
                viewAdminAccountModule.setVisible(true);
                dispose();
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "Incorrect Password");
            }
        }    
    }//GEN-LAST:event_list_ButtonActionPerformed

    private void inventory_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventory_ButtonActionPerformed
        ViewProduct viewProductModule = new ViewProduct();
        viewProductModule.setVisible(true);
        dispose(); 
    }//GEN-LAST:event_inventory_ButtonActionPerformed

    private void schedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schedule_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_schedule_ButtonActionPerformed

    private void productList_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productList_ButtonActionPerformed
        ProductList producListModule = new ProductList();
        producListModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_productList_ButtonActionPerformed

    private void logoutHome_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutHome_IconMouseClicked
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?","Logout",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
       
       if (choice == JOptionPane.NO_OPTION)
       {
           
       }
       else
       {
            JOptionPane.showMessageDialog(null, "The account has been successfully logged out.","Logout Successful",JOptionPane.INFORMATION_MESSAGE );
            Login loginModule = new Login();
            loginModule.setVisible(true);
            dispose();
       }
        
    }//GEN-LAST:event_logoutHome_IconMouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
         
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
        
    }//GEN-LAST:event_formWindowClosing

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JTextField date_TextField;
    private javax.swing.JLabel details_PhoneNumber;
    private javax.swing.JButton exit_Button;
    private javax.swing.JLabel facebook_Sabang;
    private javax.swing.JLabel facebook_SanRafael;
    private javax.swing.JLabel home_Label;
    private javax.swing.JButton inventory_Button;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JButton list_Button;
    private javax.swing.JLabel logoutHome_Icon;
    private javax.swing.JButton productList_Button;
    private javax.swing.JButton schedule_Button;
    private javax.swing.JTextField time_TextField;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
