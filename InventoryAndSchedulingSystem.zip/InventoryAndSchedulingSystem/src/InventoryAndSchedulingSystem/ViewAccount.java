package InventoryAndSchedulingSystem;

import java.util.Base64;
import javax.swing.JOptionPane;

public class ViewAccount extends javax.swing.JFrame {


    public ViewAccount() 
    {
        initComponents();
        
        name_TextField.setEditable(false);
        email_TextField.setEditable(false);
        phoneNumber_TextField.setEditable(false);
        username_TextField.setEditable(false);
        password_Field.setEditable(false);
        
    }
    
  

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        myAccount_Label = new javax.swing.JLabel();
        name_Label = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_CheckBox = new javax.swing.JCheckBox();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        name_TextField = new javax.swing.JTextField();
        email_Label = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VIEW ACCOUNT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        myAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        myAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        myAccount_Label.setText("MY ACCOUNT");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(myAccount_Label)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(myAccount_Label)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        name_Label.setText("Name");

        email_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        email_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        username_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        password_Field.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        password_Field.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                password_FieldMouseClicked(evt);
            }
        });

        showPassword_CheckBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        showPassword_CheckBox.setText("Hide Password");
        showPassword_CheckBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        showPassword_CheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPassword_CheckBoxActionPerformed(evt);
            }
        });

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number ");

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        name_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        name_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Close");
        back_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(name_Label)
                        .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(username_Label)
                        .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(password_Label)
                        .addComponent(password_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(showPassword_CheckBox)
                        .addComponent(phoneNumber_Label)
                        .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(name_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(email_Label)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addComponent(name_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(name_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(email_Label)
                .addGap(5, 5, 5)
                .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(showPassword_CheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  
    String storedPasswordHash = hashPassword("1111");
    
    private static String hashPassword(String password) 
    {
        return Base64.getEncoder().encodeToString(password.getBytes());
    }
    private static boolean isPasswordCorrect(String enteredPassword, String storedPasswordHash) 
    {
         String enteredPasswordHash = hashPassword(enteredPassword);
         return storedPasswordHash.equals(enteredPasswordHash);
    }
   
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
        
    }//GEN-LAST:event_formWindowClosing

    private void showPassword_CheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPassword_CheckBoxActionPerformed
//        String enter = JOptionPane.showInputDialog(null, "Enter Password", "Verification", JOptionPane.PLAIN_MESSAGE);
//
//        if (enter == null) 
//        {
//           
//            JOptionPane.showMessageDialog(null, "Operation canceled by user");
//        }
//        else if (enter.isEmpty()) 
//        {
//            JOptionPane.showMessageDialog(null, "Please input password");   
//        } 
//        else 
//        {
//            
//            if (isPasswordCorrect(enter, storedPasswordHash)) {
//                JOptionPane.showMessageDialog(null, "Password correct!");
//  
//                if (showPassword_CheckBox.isSelected())
//                {
//                    password_Field.setEchoChar((char)0);
//                }
//                else 
//                {
//                    password_Field.setEchoChar('•');
//                }
//        } 
//        else
//        {
//            JOptionPane.showMessageDialog(null, "Incorrect Password");
//        }
//        }


        if (showPassword_CheckBox.isSelected()){
            password_Field.setEchoChar('•');
        }
        else{
             password_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_showPassword_CheckBoxActionPerformed

    private void password_FieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_password_FieldMouseClicked
       String enter = JOptionPane.showInputDialog(null, "Enter Password", "Verification", JOptionPane.PLAIN_MESSAGE);

        if (enter == null) 
        {
           
            JOptionPane.showMessageDialog(null, "Operation canceled by user");
        }
        else if (enter.isEmpty()) 
        {
            JOptionPane.showMessageDialog(null, "Please input password");   
        } 
        else 
        {
            
            if (isPasswordCorrect(enter, storedPasswordHash)) {
                JOptionPane.showMessageDialog(null, "Password correct!");
                password_Field.setEchoChar((char)0);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Incorrect Password");
            }
        }
    }//GEN-LAST:event_password_FieldMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel email_Label;
    public static javax.swing.JTextField email_TextField;
    private javax.swing.JLabel myAccount_Label;
    private javax.swing.JLabel name_Label;
    public static javax.swing.JTextField name_TextField;
    public static javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    public static javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JCheckBox showPassword_CheckBox;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    protected static javax.swing.JTextField username_TextField;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables

}
